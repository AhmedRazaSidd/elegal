import React from 'react'
import Footer from '@/components/Footer'
import Link from 'next/link'

const article1 = () => {
  return (
   <>
      <section className='terms___section p-2'>
        {/* ====================== BANNER START ========================= */}
        <section className='banner__section'>
          <div className='container-fluid position-relative p-lg-5 p-4'>
            <div className='w-100'>
              <Link href='/'>
                <img src="/Logo.png" className='bannner___logo' alt="logo" />
              </Link>
            </div>
            <div className='w-100 d-flex align-items-center bannner___box justify-content-center'>
              <div className='text-center col-xxl-8 col-lg-6 col-12'>
                <h1 className='text-white display-6 main___banner___title'>E-Legal AI Revolutionizes Legal Documents: Simplifying legalese with AI</h1>
                <p className='   text-white mt-lg-4 mt-2 main___banner___p'>Published On: April 11th, 2023</p>
              </div>
            </div>
            <img src="/article.png" className='banner__img' alt="image" />
          </div>
        </section>
        {/* ====================== BANNER END ========================= */}

        {/* ====================== TEXT CONTENT START ========================= */}
        <section className='text___content___section'>
          <div className='container'>
            <div className='row justify-content-center mt-lg-0 mt-4 mb-lg-5 mb-3'>
              <p className='text-gry text-center'>Updated on February 20, 2023</p>
              <div className='txt___content___p col-lg-7 col-12'>
                <p className='fw-bold fs-5 fst-italic'>New Tool Simplifies ANY Legal Document, from Settlements to Rental Agreements, Lawsuits, and More</p>
                  <p>
                    MIAMI, April 11, 2023 – E-Legal, a groundbreaking new tool powered by artificial intelligence, launched today to help people understand legal documents before signing them. Every day, millions of Americans are presented with legally binding agreements they do not understand yet are encouraged to sign. While some agreements are harmless, others, such as real estate purchases, employment agreements, and severance agreements, can have significant impacts. E-Legal utilizes advanced algorithms to analyze legal documents and translate their legalese into simple language quickly and accurately.
                  </p>
                  <p>
                    <span className='fst-italic fw-bold'>“Everyone should understand what they are signing,” said Tam Danier, founder of E-Legal AI. “</span>
                    Contracts are often lengthy and difficult to absorb quickly, and that's where E-Legal AI comes in – simplifying complicated legal language into words elementary-aged kids can understand. AI makes this possible, leveling the playing field. It's a great equalizer.”
                  </p>
                  <p>
                      E-Legal AI analyzes complex contracts and translates legal jargon into simple and concise language. Users can quickly identify potential issues or areas of concern, including ambiguous language and discrepancies, because E-Legal provides a more natural and reader-friendly transcription.
                  </p>
                  <p>
                     Users can safely and securely upload a contract or other legal document. E-Legal AI quickly analyzes the verbiage and returns a detailed but concise translation in straightforward language.
                  </p>
                  <p>
                     To learn more about or to E-Legal, visit www.e-legal.ai
                  </p>
                  <h6 className='fw-bold'>ABOUT E-LEGAL</h6>
                  <p>
                      E-Legal AI is an innovative tool that simplifies legal jargon and makes contracts easy to understand. E-Legal’s AI Technology simplifies legal jargon, so you can understand the terms clearly before signing, saving time and money and reducing the risk of legal disputes.
                  </p>
                  <span>
                    <h6 className='fw-bold d-inline'>CONTACT: </h6>
                    hello@e-legal.ai
                  </span>
              </div>
            </div>
          </div>
        </section>
        {/* ====================== TEXT CONTENT END ========================= */}

        {/* ====================== FOOTER START ========================= */}
          <Footer/>
        {/* ====================== FOOTER END ========================= */}
        

      </section>
   </>
  )
}

export default article1